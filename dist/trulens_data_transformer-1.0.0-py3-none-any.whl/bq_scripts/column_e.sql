-- Removed unsupported USE statement

DROP TABLE IF EXISTS `your-project.your_dataset.column_e_temp`;

CREATE TABLE
  `your-project.your_dataset.column_e_temp` (
    product STRING,
    `database` STRING,
    schema STRING,
    object_name STRING,
    name STRING,
    username STRING,
    column_position INT64,
    data_type STRING,
    column_length INT64,
    column_precision INT64,
    column_scale INT64,
    column_format STRING,
    default_value STRING,
    nullable BOOLEAN,
    is_uppercase BOOLEAN,
    is_case_sensitive BOOLEAN,
    column_constraint STRING,
    compressible BOOLEAN,
    compress_value_list STRING,
    create_timestamp BIGINT,
    update_timestamp BIGINT,
    instance_id STRING
  );

-- Replaced placeholder with regex pattern

INSERT INTO
  `your-project.your_dataset.column_e_temp`
SELECT
  'big_query',
  table_catalog,
  table_schema,
  table_name,
  column_name,
  '' AS username,
  RANK() OVER (
    PARTITION BY
      table_catalog,
      table_schema,
      table_name
    ORDER BY
      CAST(ordinal_position AS INT64) ASC
  ),
  CASE
    WHEN UPPER(data_type_name) = 'BOOL' THEN 'BOOLEAN'
    WHEN UPPER(data_type_name) = 'BYTES' THEN 'VARBINARY'
    WHEN UPPER(data_type_name) = 'DATE' THEN 'DATE'
    WHEN UPPER(data_type_name) = 'DATETIME' THEN 'TIMESTAMP'
    WHEN UPPER(data_type_name) = 'GEOGRAPHY' THEN 'VARCHAR'
    WHEN UPPER(data_type_name) = 'INTERVAL' THEN 'INTERVAL_YEAR_MONTH'
    WHEN UPPER(data_type_name) = 'JSON' THEN 'JSON'
    WHEN UPPER(data_type_name) = 'INT64' THEN 'BIGINT'
    WHEN UPPER(data_type_name) = 'INT' THEN 'BIGINT'
    WHEN UPPER(data_type_name) = 'SMALLINT' THEN 'BIGINT'
    WHEN UPPER(data_type_name) = 'INTEGER' THEN 'BIGINT'
    WHEN UPPER(data_type_name) = 'BIGINT' THEN 'BIGINT'
    WHEN UPPER(data_type_name) = 'TINYINT' THEN 'BIGINT'
    WHEN UPPER(data_type_name) = 'BYTEINT' THEN 'BIGINT'
    WHEN UPPER(data_type_name) = 'NUMERIC' THEN 'DECIMAL'
    WHEN UPPER(data_type_name) LIKE 'DECIMAL' THEN 'DECIMAL'
    WHEN UPPER(data_type_name) = 'BIGNUMERIC' THEN 'DECIMAL'
    WHEN UPPER(data_type_name) = 'BIGDECIMAL' THEN 'DECIMAL'
    WHEN UPPER(data_type_name) = 'TIME' THEN 'TIME'
    WHEN UPPER(data_type_name) = 'TIMESTAMP' THEN 'TIMESTAMP'
    WHEN UPPER(data_type_name) = 'FLOAT64' THEN 'FLOAT64'
    WHEN UPPER(data_type_name) = 'STRING' THEN 'VARCHAR'
    WHEN UPPER(data_type_name) LIKE 'ARRAY<STRUCT%' THEN 'ARRAY<STRUCT>'
    WHEN UPPER(data_type_name) LIKE 'STRUCT%' THEN 'STRUCT'
    WHEN UPPER(data_type_name) LIKE 'ARRAY%' THEN 'ARRAY'
    ELSE 'ANY'
  END AS data_type,
  COALESCE(CAST(data_type_precision AS INT64), 0) AS column_length,
  COALESCE(CAST(data_type_precision AS INT64), 0) AS column_precision,
  COALESCE(CAST(data_type_scale AS INT64), 0) AS column_scale,
  CAST(NULL AS STRING) AS column_format,
  CAST(NULL AS STRING) AS default_value,
  FALSE AS nullable,
  FALSE AS is_uppercase,
  FALSE AS is_case_sensitive,
  CAST(NULL AS STRING) AS column_constraint,
  FALSE AS compressible,
  CAST(NULL AS STRING) AS compress_value_list,
  CASE
    WHEN CURRENT_TIMESTAMP() IS NOT NULL
    THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
    ELSE UNIX_SECONDS(CAST(creation_time AS TIMESTAMP))
  END AS create_timestamp,
  NULL AS update_timestamp,
  'your-instance-id' AS instance_id
FROM
  (
    SELECT
      col.table_catalog,
      col.table_schema,
      col.table_name,
      col.column_name,
      col.ordinal_position,
      t.creation_time,
      col.DATA_TYPE,
      REGEXP_EXTRACT(col.DATA_TYPE, '([^, ()\\n\\r]+)') AS data_type_name,
      REGEXP_EXTRACT(col.DATA_TYPE, '([^, ()\\n\\r]+\\(\\d+\\))') AS data_type_precision,
      REGEXP_EXTRACT(col.DATA_TYPE, '([^, ()\\n\\r]+\\(\\d+,\\d+\\))') AS data_type_scale
    FROM
      `your-project.your_dataset.COLUMNS` col
      LEFT JOIN `your-project.your_dataset.TABLES` t ON col.table_catalog = t.table_catalog
      AND col.table_schema = t.table_schema
      AND col.table_name = t.table_name
  );

DROP TABLE IF EXISTS `your-project.your_dataset.column_e`;

CREATE TABLE
  `your-project.your_dataset.column_e` (
    product STRING,
    `database` STRING,
    schema STRING,
    object_name STRING,
    name STRING,
    username STRING,
    column_position INT64,
    data_type STRING,
    column_length INT64,
    column_precision INT64,
    column_scale INT64,
    column_format STRING,
    default_value STRING,
    nullable BOOLEAN,
    is_uppercase BOOLEAN,
    is_case_sensitive BOOLEAN,
    column_constraint STRING,
    compressible BOOLEAN,
    compress_value_list STRING,
    create_timestamp BIGINT,
    update_timestamp BIGINT,
    instance_id STRING
  );

INSERT INTO
  `your-project.your_dataset.column_e`
SELECT
  'big_query',
  `database`,
  schema,
  object_name,
  name,
  username,
  column_position,
  CASE
    WHEN data_type LIKE 'Received Exception%' THEN 'ANY'
    ELSE data_type
  END,
  column_length,
  column_precision,
  column_scale,
  NULL,
  NULL,
  FALSE,
  FALSE,
  FALSE,
  NULL,
  FALSE,
  CAST(NULL AS STRING) AS compress_value_list,
 CASE
    WHEN CURRENT_TIMESTAMP() IS NOT NULL
    THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
    ELSE create_timestamp
 END AS create_timestamp,
 CASE
    WHEN CURRENT_TIMESTAMP() IS NOT NULL
    THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
    ELSE update_timestamp
 END AS update_timestamp,
  'your-instance-id' AS instance_id
FROM
  `your-project.your_dataset.column_e_temp`
WHERE
  schema IS NOT NULL
  AND object_name IS NOT NULL
  AND name IS NOT NULL;