DROP TABLE IF EXISTS `your-project.your_dataset.partition_e`;

CREATE TABLE `your-project.your_dataset.partition_e` (
  product STRING,
  instance_id STRING,
  `database` STRING,
  schema STRING,
  table_name STRING,
  partition_name STRING,
  partition_columns ARRAY<STRING>,
  partition_text STRING,
  user_name STRING,
  partitionColumnSize INT64,
  create_timestamp INT64
);

INSERT INTO `your-project.your_dataset.partition_e`
SELECT
  'big_query' AS product,
  'your-instance-id' AS instance_id,
  col.table_catalog AS `database`,
  col.table_schema AS schema,
  col.table_name AS table_name,
  NULL AS partition_name,
  ARRAY_AGG(col.column_name ORDER BY col.column_name) AS partition_columns,
  NULL AS partition_text,
  NULL AS user_name,
  0 AS partitionColumnSize,
  CASE
    WHEN CURRENT_TIMESTAMP() IS NOT NULL
    THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
    ELSE NULL -- Replaced undefined `create_timestamp` with NULL
  END AS create_timestamp
FROM
  `your-project.your_dataset.COLUMNS` col
WHERE
  IS_PARTITIONING_COLUMN = 'YES'
GROUP BY
  col.table_catalog,
  col.table_schema,
  col.table_name;
