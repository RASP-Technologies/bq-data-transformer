-- Drop the table if it exists
DROP TABLE IF EXISTS `your-project.your_dataset.indices_e`;

-- Create the table
CREATE TABLE `your-project.your_dataset.indices_e` (
  product STRING,
  `database` STRING,
  schema STRING,
  name STRING,
  username STRING,
  columns ARRAY<STRING>,
  indexname STRING,
  indextype STRING,
  ddl STRING,
  uniqueflag BOOL,
  create_timestamp INT64,
  update_timestamp INT64,
  instance_id STRING
);

-- Insert data into the table
INSERT INTO `your-project.your_dataset.indices_e` (
  product,
  instance_id,
  `database`,
  schema,
  name,
  columns,
  indextype,
  indexname,
  username,
  ddl,
  uniqueflag,
  create_timestamp,
  update_timestamp
)
SELECT
  product,
  instance,
  table_catalog,
  table_schema,
  table_name,
  ARRAY_AGG(column_name) AS columns, -- Removed ORDER BY clause
  'cluster' AS indextype,
  NULL AS indexname,
  NULL AS username,
  NULL AS ddl,
  FALSE AS uniqueflag,
  CASE
    WHEN CURRENT_TIMESTAMP() IS NOT NULL
    THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
    ELSE NULL -- Replaced undefined `create_timestamp` with NULL
  END AS create_timestamp,
  NULL AS update_timestamp
FROM
  (
    SELECT
      product,
      instance,
      table_catalog,
      table_schema,
      table_name,
      column_name
    FROM
      (
        SELECT
          'big_query' AS product,
          'your-instance-id' AS instance, -- Replace with actual instance ID
          table_catalog,
          table_schema,
          table_name,
          clustering_ordinal_position,
          column_name
        FROM
          `your-project.your_dataset.COLUMNS` c
        WHERE
          clustering_ordinal_position IS NOT NULL
        ORDER BY clustering_ordinal_position -- Moved ORDER BY outside of ARRAY_AGG
      ) AS clustering_columns
  )
GROUP BY
  product,
  instance,
  table_catalog,
  table_schema,
  table_name
