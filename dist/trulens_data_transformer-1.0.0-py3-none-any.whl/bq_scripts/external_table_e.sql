-- Drop the table if it exists
DROP TABLE IF EXISTS `your-project.your_dataset.external_table_e`;

-- Create the external table
CREATE OR REPLACE TABLE `your-project.your_dataset.external_table_e` AS
SELECT
    'big_query' AS product,
    t.table_catalog AS `database`,
    t.table_schema AS `schema`,
    t.table_name AS name,
    t.table_type AS type,
    REGEXP_REPLACE(REGEXP_EXTRACT(t.ddl, r'(?i)uris\s*=\s*\[(.*)\]'), r'"', '') AS external_object_name,
    CASE
        WHEN CURRENT_TIMESTAMP() IS NOT NULL
        THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
        ELSE NULL -- Removed create_timestamp reference
    END AS create_timestamp,
    CASE
        WHEN CURRENT_TIMESTAMP() IS NOT NULL
        THEN CURRENT_TIMESTAMP()
        ELSE TIMESTAMP_SECONDS(UNIX_SECONDS(t.creation_time))
    END AS update_timestamp,
    'your-instance-id' AS instance_id
FROM
    `your-project.your_dataset.TABLES` t
WHERE
    t.table_type = 'EXTERNAL';
