-- Drop and recreate the main query log table
DROP TABLE IF EXISTS `your-project.your_dataset.query_log_e`;

CREATE TABLE `your-project.your_dataset.query_log_e` (
  product STRING,
  default_database STRING,
  default_schema STRING,
  query_id STRING,
  sql_text STRING,
  session_id STRING,
  user_name STRING,
  start_time INT64,
  execution_time INT64,
  cpu_time INT64,
  app_id STRING,
  io_count INT64,
  is_stored_proc_query BOOL,
  proc_id INT64,
  instance_id STRING,
  is_command BOOL,
  command_payload_schema STRUCT<
    entity_type STRING,
    cmd_kind STRING,
    command_config_schema STRUCT<
      source STRING,
      destination STRING
    >,
    schema_json STRING,
    create_time INT64,
    update_time INT64,
    entity_name STRING,
    view_sql STRING
  >,
  workload_reservation_id STRING,
  hardware_util_ms INT64
);

-- Insert transformed job data without unnesting
INSERT INTO `your-project.your_dataset.query_log_e`
SELECT
  'big_query' AS product,
  project_id AS default_database,
  destination_dataset_id AS default_schema,
  job_id AS query_id,
  query AS sql_text,
  CASE
    WHEN parent_job_id IS NOT NULL THEN parent_job_id
    WHEN JSON_EXTRACT_SCALAR(CAST(session_info AS STRING), "$.session_id") IS NOT NULL THEN JSON_EXTRACT_SCALAR(CAST(session_info AS STRING), "$.session_id")
    ELSE job_id
  END AS session_id,
  user_email AS user_name,
  CAST(UNIX_SECONDS(start_time) AS INT64) AS start_time,
  CAST((UNIX_SECONDS(end_time) - UNIX_SECONDS(start_time)) AS INT64) AS execution_time,
  0 AS cpu_time,  -- default value, since we are ignoring unnesting logic
  user_email AS app_id,
  total_bytes_processed AS io_count,
  CASE
    WHEN parent_job_id IS NOT NULL OR JSON_EXTRACT_SCALAR(CAST(session_info AS STRING), "$.session_id") IS NOT NULL THEN TRUE
    ELSE FALSE
  END AS is_stored_proc_query,
  0 AS proc_id,
  '' AS instance_id,
  FALSE AS is_command,
  STRUCT(
    '' AS entity_type,
    '' AS cmd_kind,
    STRUCT(CAST(NULL AS STRING) AS source, CAST(NULL AS STRING) AS destination) AS command_config_schema,
    '' AS schema_json,
    NULL AS create_time,
    NULL AS update_time,
    '' AS entity_name,
    '' AS view_sql
  ) AS command_payload_schema,
  reservation_id AS workload_reservation_id,
  total_slot_ms AS hardware_util_ms
FROM
  `your-project.your_dataset.JOBS_BY_PROJECT`
WHERE
  state = 'DONE'
  AND (error_result_reason IS NULL OR error_result_reason = 'responseTooLarge')
  AND job_type = 'QUERY';

-- Create a deduplicated version of the query log
CREATE OR REPLACE TABLE `your-project.your_dataset.query_log_e_dedupe` AS
SELECT *
FROM (
  SELECT *,
         ROW_NUMBER() OVER (PARTITION BY sql_text, user_name, app_id ORDER BY start_time ASC) AS row_num,
         COUNT(*) OVER (PARTITION BY sql_text, user_name, app_id) AS query_count
  FROM `your-project.your_dataset.query_log_e`
)
WHERE row_num = 1;
