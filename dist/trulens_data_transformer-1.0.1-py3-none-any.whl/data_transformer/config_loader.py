import configparser

def load_config(path="config/config.ini"):
    config = configparser.ConfigParser()
    config.read(path)

    general = config['general']
    return {
        "project_id": general.get("project_id"),
        "dataset_id": general.get("dataset_id"),
        "region": general.get("region"),
        "input_folder": general.get("input_folder"),
        "bucket_name": general.get("bucket_name"),
        "gcs_output_uri": general.get("gcs_output_uri"),
        "sql_folder": general.get("sql_folder"),
        "service_account_json": general.get("service_account_json"),
    }
