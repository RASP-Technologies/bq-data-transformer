import fastavro
import pyarrow as pa
from google.cloud import bigquery, storage
from google.api_core.exceptions import Conflict, NotFound
from collections import defaultdict
from google.api_core.retry import Retry
import re
from data_transformer.config_loader import load_config
import zipfile
import os

class BigQueryDataProcessor:
    def __init__(self, project_id, dataset_id, region, bucket_name, input_folder,
                 gcs_output_uri, sql_folder, service_account_json):
        self.project_id = project_id
        self.dataset_id = dataset_id
        self.region = region
        self.bucket_name = bucket_name
        self.input_folder = input_folder
        self.gcs_output_uri = gcs_output_uri
        self.sql_folder = sql_folder
        self.instance_id = " "
        self.service_account_json = service_account_json

        # Initialize clients
        self.bq_client = self.get_bigquery_client(project_id=project_id, service_account_json=service_account_json)
        self.gcs_client = self.get_storage_client(service_account_json=service_account_json)
    
    def get_bigquery_client(self, project_id, service_account_json):
        return bigquery.Client(
            project=project_id,
            credentials=bigquery.Client.from_service_account_json(service_account_json)._credentials
        )
    
    def get_storage_client(self, service_account_json):
        try:
            if not os.path.exists(service_account_json):
                raise FileNotFoundError(f"Service account file not found: {service_account_json}")

            client = storage.Client.from_service_account_json(service_account_json)
            print("Storage client created successfully.")
            return client

        except Exception as e:
            print(f"Failed to create storage client: {e}")
            raise

    def zip_files(self, source_zip='Parquet.zip', destination_folder='Ext_Parquet_files'):
        # zip_file_path = source_zip
        # extract_folder = 'Ext_Parquet_files'  # Folder where the contents will be extracted

        # Ensure the folder exists, create it if not
        os.makedirs(destination_folder, exist_ok=True)
        # if os.path.exists(destination_folder):
        #     for filename in os.listdir(destination_folder):
        #         file_path = os.path.join(destination_folder, filename)
        #         if os.path.isfile(file_path):
        #             os.remove(file_path)

        # Open the zip file and extract its contents
        with zipfile.ZipFile(source_zip, 'r') as zip_ref:
            zip_ref.extractall(destination_folder)

        print(f'Files extracted to {destination_folder}')
    
    def files_to_gcs(self, source_folder):
        """Uploads files from a local folder to a GCS bucket."""
        bucket = self.gcs_client.bucket(self.bucket_name)
        prefix = f"{self.input_folder}/{self.project_id}/{self.region}/{self.dataset_id}/"
        destination_folder = os.path.join(prefix)

        for root, _, files in os.walk(source_folder):
            for file in files:
                local_path = os.path.join(root, file)
                relative_path = os.path.relpath(local_path, source_folder)
                gcs_path = os.path.join(destination_folder, relative_path)

                blob = bucket.blob(gcs_path)
                blob.upload_from_filename(local_path)
                print(f"Uploaded {local_path} to gs://{self.bucket_name}/{gcs_path}")

    def _list_parquet_tables_from_gcs(self):
        """Groups Parquet files by table name from GCS directory structure."""
        prefix = f"{self.input_folder}/{self.project_id}/{self.region}/{self.dataset_id}/"
        bucket = self.gcs_client.bucket(self.bucket_name)
        blobs = bucket.list_blobs(prefix=prefix)

        # Group blobs by table name (directory-based)
        table_files = defaultdict(list)

        for blob in blobs:
            if blob.name.endswith('.parquet'):
                file_name = blob.name.split("/")[-1]
                parts = file_name.split('.')
                if len(parts) < 3:
                    continue  # Skip invalid files
                    
                table_name = parts[0]  # First part is the table name
                gcs_uri = f"gs://{self.bucket_name}/{blob.name}"
                table_files[table_name].append(gcs_uri)

        return table_files

    @Retry()  # Handles transient errors
    def create_external_tables_from_parquet(self):
        """Creates external BigQuery tables that reference grouped Parquet files in GCS."""
        table_files = self._list_parquet_tables_from_gcs()

        for table_name, uris in table_files.items():
            table_id = f"{self.project_id}.{self.dataset_id}.{table_name}"
            dataset_ref = bigquery.DatasetReference(self.project_id, self.dataset_id)
            table_ref = dataset_ref.table(table_name)

            try:
                self.bq_client.delete_table(table_ref)
                print(f"[BigQuery] Deleted existing table: {table_id}")
            except NotFound:
                pass  # Table does not exist, no action needed

            external_config = bigquery.ExternalConfig(source_format=bigquery.SourceFormat.PARQUET)
            external_config.source_uris = uris  # List of GCS URIs or wildcard path
            table = bigquery.Table(table_ref)
            table.external_data_configuration = external_config

            try:
                self.bq_client.create_table(table)
                print(f"[BigQuery] Created external table: {table_id}")
            except Conflict:
                print(f"[BigQuery] Table already exists: {table_id}")
    
    def run_sql_scripts(self):
        """Execute SQL scripts with robust placeholder replacement and validation"""
        # Get list of pre-loaded tables from GCS
        loaded_tables = self._list_parquet_tables_from_gcs().keys()

        for sql_file in os.listdir(self.sql_folder):
            if sql_file.endswith(".sql") and not sql_file.startswith("__"):
                try:
                    with open(os.path.join(self.sql_folder, sql_file), 'r') as f:
                        query = f.read()

                    # Comprehensive placeholder replacement
                    formatted_query = (query
                        .replace("${project_id}", self.project_id)
                        .replace("${dataset_id}", self.dataset_id)
                        .replace("{project_id}", self.project_id)
                        .replace("{dataset_id}", self.dataset_id)
                        .replace("your-project.your_dataset", f"{self.project_id}.{self.dataset_id}")
                        .replace("your-project", self.project_id)
                        .replace("your_dataset", self.dataset_id)
                        .replace("your-instance-id", self.instance_id))

                    # Extract source tables ignoring temp tables
                    source_tables = self._extract_source_tables(formatted_query)
                    
                    # Validate source tables exist
                    missing_tables = [t for t in source_tables if t not in loaded_tables]
                    if missing_tables:
                        available_tables = "\n".join(sorted(loaded_tables))
                        raise ValueError(
                            f"Missing source tables in {sql_file}: {missing_tables}\n"
                            f"Loaded tables:\n{available_tables}"
                        )

                    # Execute with retries and timeout
                    job = self.bq_client.query(
                        formatted_query,
                        retry=Retry(deadline=300)  # 5 minutes
                    )
                    job.result()
                    print(f"Successfully executed {sql_file}")

                except Exception as e:
                    print(f" Critical error in {sql_file}:")
                    print(f"Query snippet:\n{formatted_query[:500]}...")
                    raise RuntimeError(f"Failed to execute {sql_file}") from e

    def _extract_source_tables(self, query):
        """Extracts real source table names from SQL, excluding created tables and SQL keywords."""

        # Lowercase version for consistent matching
        query_lower = query.lower()

        # Detect tables created within the script
        create_pattern = r'create\s+(or\s+replace\s+)?(table|view)\s+`?(?:{0}\.{1}\.)?([a-z0-9_]+)`?'.format(
            re.escape(self.project_id.lower()),
            re.escape(self.dataset_id.lower())
        )
        created_tables = {m.group(3).lower() for m in re.finditer(create_pattern, query_lower)}

        # Match table references in FROM or JOIN clauses
        from_join_pattern = r'(?:from|join)\s+`?(?:{0}\.{1}\.)?([a-z0-9_]+)`?'.format(
            re.escape(self.project_id.lower()),
            re.escape(self.dataset_id.lower())
        )
        matches = re.findall(from_join_pattern, query, re.IGNORECASE)

        # SQL keywords to ignore — lowercase only
        sql_keywords = {
            'if', 'and', 'or', 'as', 'on', 'where', 'group', 'order', 'having',
            'limit', 'offset', 'for', 'into', 'by', 'left', 'right', 'inner',
            'outer', 'full', 'union', 'except', 'intersect', 'select', 'insert',
            'update', 'delete', 'merge', 'when', 'then', 'else', 'using', 'with',
            'case', 'end', 'distinct', 'all', 'over', 'partition', 'range', 'rows',
            'current', 'row', 'between', 'unbounded', 'preceding', 'following'
        }

        # Filter valid source tables
        source_tables = {
            t for t in matches
            if t.lower() not in sql_keywords
            and not t.lower().startswith(('temp_', '_temp'))
            and not t.lower().endswith(('_temp', '_tmp'))
            and t.lower() not in created_tables
        }

        return list(source_tables)

    def export_and_convert_results(self):
        """Converts BigQuery results to Parquet via streaming."""
        bucket = self.gcs_client.bucket(self.gcs_output_uri.split('/')[2])

        # Process each result table
        for sql_file in os.listdir(self.sql_folder):
            if sql_file.endswith(".sql") and not sql_file.startswith("__"):
                table_name = os.path.splitext(sql_file)[0]
                source_table = f"{self.project_id}.{self.dataset_id}.{table_name}"

                # Export to Avro
                avro_prefix = f"temp_avro/{table_name}/"
                avro_uri = f"gs://{bucket.name}/{avro_prefix}*.avro"
                extract_job = self.bq_client.extract_table(
                    source_table,
                    avro_uri,
                    job_config=bigquery.ExtractJobConfig(destination_format="AVRO")
                )
                extract_job.result()

                # Convert to Parquet in streaming fashion
                self._convert_avro_to_parquet(bucket, avro_prefix, table_name)

                self._delete_gcs_prefix(bucket, avro_prefix)
        print(f"Deleted all temporary Avro files")

    def _convert_avro_to_parquet(self, bucket, avro_prefix, table_name):
        """Converts Avro to Parquet using fastavro with batch processing"""
        from pyarrow import Table
        import pyarrow.parquet as pq

        # Create output blob
        output_path = f"cleaned_parquet/{table_name}.parquet"
        output_blob = bucket.blob(output_path)
        writer = None

        with output_blob.open("wb") as parquet_file:
            for blob in bucket.list_blobs(prefix=avro_prefix):
                if not blob.name.endswith('.avro'):
                    continue

                with blob.open('rb') as avro_file:
                    reader = fastavro.reader(avro_file)
                    schema = reader.writer_schema

                    # Convert Avro schema to PyArrow schema
                    fields = []
                    for field in schema['fields']:
                        pa_type = self._avro_type_to_pyarrow(field['type'])
                        fields.append(pa.field(field['name'], pa_type))
                    
                    arrow_schema = pa.schema(fields)

                    # Process records in batches
                    batch_size = 10000
                    records = []
                    for record in reader:
                        records.append(record)
                        if len(records) >= batch_size:
                            table = Table.from_pylist(records, schema=arrow_schema)
                            if not writer:
                                writer = pq.ParquetWriter(
                                    parquet_file,
                                    arrow_schema,
                                    compression='SNAPPY'
                                )
                            writer.write_table(table)
                            records = []

                    # Write remaining records
                    if records:
                        table = Table.from_pylist(records, schema=arrow_schema)
                        if not writer:
                            writer = pq.ParquetWriter(
                                parquet_file,
                                arrow_schema,
                                compression='SNAPPY'
                            )
                        writer.write_table(table)

            if writer:
                writer.close()
        print(f"[Parquet] Converted and saved: cleaned_parquet/{table_name}.parquet")

    def _avro_type_to_pyarrow(self, avro_type):
        """Converts Avro types to PyArrow types including logical types."""
        type_map = {
            'string': pa.string(),
            'int': pa.int32(),
            'long': pa.int64(),
            'float': pa.float32(),
            'double': pa.float64(),
            'boolean': pa.bool_(),
            'bytes': pa.binary(),
            'null': pa.null()
        }

        if isinstance(avro_type, list):
            # Handle union types (e.g., ["null", "long"])
            non_null = [t for t in avro_type if t != 'null']
            return self._avro_type_to_pyarrow(non_null[0])

        if isinstance(avro_type, dict):
            logical_type = avro_type.get('logicalType')
            base_type = avro_type['type']

            if logical_type == 'timestamp-millis' or logical_type == 'timestamp-micros':
                unit = 'ms' if logical_type.endswith('millis') else 'us'
                return pa.timestamp(unit)
            elif logical_type == 'date':
                return pa.date32()
            elif base_type == 'array':
                return pa.list_(self._avro_type_to_pyarrow(avro_type['items']))
            elif base_type == 'map':
                return pa.map_(pa.string(), self._avro_type_to_pyarrow(avro_type['values']))
            elif base_type == 'record':
                fields = [
                    pa.field(f['name'], self._avro_type_to_pyarrow(f['type']))
                    for f in avro_type['fields']
                ]
                return pa.struct(fields)
            else:
                return type_map.get(base_type, pa.string())

        return type_map.get(avro_type, pa.string())  # Fallback
    
    def _delete_gcs_prefix(self, bucket, prefix):
        """Deletes all blobs in GCS with the given prefix (like a folder)."""
        blobs = list(bucket.list_blobs(prefix=prefix))
        for blob in blobs:
            blob.delete()

    def run_sql_scripts_inside(self):
        """Execute SQL scripts bundled inside the .whl file"""
        from importlib.resources import files

        # The dotted path to your package where sql_folder exists
        sql_pkg = 'bq_scripts'

        loaded_tables = self._list_parquet_tables_from_gcs().keys()

        # List .sql files in the embedded folder
        for resource in files(sql_pkg).iterdir():
            if resource.name.endswith(".sql") and not resource.name.startswith("__"):
                try:
                    query = resource.read_text()

                    formatted_query = (query
                                       .replace("${project_id}", self.project_id)
                                       .replace("${dataset_id}", self.dataset_id)
                                       .replace("{project_id}", self.project_id)
                                       .replace("{dataset_id}", self.dataset_id)
                                       .replace("your-project.your_dataset", f"{self.project_id}.{self.dataset_id}")
                                       .replace("your-project", self.project_id)
                                       .replace("your_dataset", self.dataset_id)
                                       .replace("your-instance-id", self.instance_id))

                    source_tables = self._extract_source_tables(formatted_query)
                    missing_tables = [t for t in source_tables if t not in loaded_tables]
                    if missing_tables:
                        available_tables = "\n".join(sorted(loaded_tables))
                        raise ValueError(
                            f"Missing source tables in {resource.name}: {missing_tables}\n"
                            f"Loaded tables:\n{available_tables}"
                        )

                    job = self.bq_client.query(formatted_query, retry=Retry(deadline=300))
                    job.result()
                    print(f"Successfully executed {resource.name}")

                except Exception as e:
                    print(f" Critical error in {resource.name}:")
                    print(f"Query snippet:\n{formatted_query[:500]}...")
                    raise RuntimeError(f"Failed to execute {resource.name}") from e

def main():
    # Configuration parameters
    config = load_config()

    # Initialize processor
    processor = BigQueryDataProcessor(**config)
    processor.zip_files('Parquet.zip', 'Ext_Parquet_files')
    processor.files_to_gcs('Ext_Parquet_files')
    # Execute processing pipeline
    processor.create_external_tables_from_parquet()
    processor.run_sql_scripts_inside()
    processor.export_and_convert_results()

if __name__ == "__main__":
    # Configuration parameters
    main()