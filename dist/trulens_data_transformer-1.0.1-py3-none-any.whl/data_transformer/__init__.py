"""
data_transformer package

Modules:
- bigquery_wrapper: Main script for processing and exporting BigQuery data.
- config_loader: Loads and validates configuration from config.ini.

Exports:
- main(): Entry point for CLI.
- load_config(): Loads configuration from config/config.ini.
"""

from .bigquery_wrapper import main
from .config_loader import load_config

__all__ = ["main", "load_config"]
