DROP TABLE IF EXISTS `your-project.your_dataset.macro_e`;

CREATE TABLE `your-project.your_dataset.macro_e` (
  `DATABASE` STRING,
    `SCHEMA` STRING,
    `NAME` STRING,
  username STRING,
  sql_text STRING,
  create_timestamp INT64,
  update_timestamp INT64,
  instance_id STRING
);
