DROP TABLE IF EXISTS `your-project.your_dataset.view_e`;

CREATE TABLE `your-project.your_dataset.view_e` (
  product STRING,
  `database` STRING,
  schema STRING,
  name STRING,
  sql_text STRING,
  type STRING,
  username STRING,
  create_timestamp INT64,
  update_timestamp INT64,
  instance_id STRING
);

INSERT INTO `your-project.your_dataset.view_e`
SELECT
  'big_query' AS product,
  t.table_catalog AS `database`,
  t.table_schema AS schema,
  t.table_name AS name,
  t.ddl AS sql_text,
  t.table_type AS type,
  '' AS username,
  CASE
    WHEN CURRENT_TIMESTAMP() IS NOT NULL
    THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
    ELSE NULL -- Replaced undefined `create_timestamp` with NULL
  END AS create_timestamp,
  CASE
    WHEN CURRENT_TIMESTAMP() IS NOT NULL
    THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
    ELSE UNIX_SECONDS(TIMESTAMP_SECONDS(CAST(ts.last_modified_time AS INT64))) -- Converted TIMESTAMP to INT64
  END AS update_timestamp,
  'your-instance-id' AS instance_id
FROM
  `your-project.your_dataset.TABLES` t
LEFT JOIN
  `your-project.your_dataset.TABLES__` ts -- Added missing join for alias `ts`
ON
  t.table_catalog = ts.project_id
  AND t.table_schema = ts.dataset_id
  AND t.table_name = ts.table_id
WHERE
  t.table_type IN ('MATERIALIZED VIEW', 'VIEW');
