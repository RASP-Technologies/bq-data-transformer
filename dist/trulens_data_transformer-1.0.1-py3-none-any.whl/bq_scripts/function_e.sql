DROP TABLE IF EXISTS `your-project.your_dataset.function_e`;

CREATE TABLE `your-project.your_dataset.function_e` (
  product STRING,
  database STRING,
  schema STRING,
  name STRING,
  sql_text STRING,
  username STRING,
  create_timestamp INT64,
  update_timestamp INT64,
  instance_id STRING
);

INSERT INTO `your-project.your_dataset.function_e`
SELECT
  'big_query' AS product,
  r.routine_catalog AS database,
  r.routine_schema AS schema,
  r.routine_name AS name,
  r.ddl AS sql_text,
  '' AS username,
  COALESCE(NULL, CAST(UNIX_SECONDS(r.created) AS INT64)) AS create_timestamp,
  COALESCE(NULL, CAST(UNIX_SECONDS(r.last_altered) AS INT64)) AS update_timestamp,
  'your-instance-id' AS instance_id
FROM
  `your-project.your_dataset.ROUTINES` r
WHERE
  r.routine_type = 'FUNCTION';
