-- Drop the table if it exists
DROP TABLE IF EXISTS `your-project.your_dataset.table_e`;

-- Create or replace the table with table metadata
CREATE OR REPLACE TABLE `your-project.your_dataset.table_e` AS
SELECT
    'big_query' AS product,
    t.table_catalog AS `database`,
    t.table_schema AS schema,
    t.table_name AS name,
    '' AS username,
    CASE
        WHEN ts.size_bytes is null THEN 0.0
        ELSE ts.size_bytes / (1024*1024)
    END AS size_in_mb, -- Added alias for column 6
    CASE
        WHEN CURRENT_TIMESTAMP() IS NOT NULL
        THEN UNIX_SECONDS(CURRENT_TIMESTAMP())
        ELSE NULL -- Replaced undefined `create_timestamp` with NULL
    END AS create_timestamp,
    CASE
        WHEN CURRENT_TIMESTAMP() IS NOT NULL
        THEN CURRENT_TIMESTAMP()
        ELSE TIMESTAMP_SECONDS(UNIX_SECONDS(t.creation_time)) -- Fixed invalid cast by using UNIX_SECONDS
    END AS update_timestamp,
FROM
    `your-project.your_dataset.TABLES` t
LEFT JOIN
    `your-project.your_dataset.TABLES__` ts
ON
    t.table_catalog = ts.project_id
    AND t.table_schema = ts.dataset_id
    AND t.table_name = ts.table_id
WHERE
    t.table_type = 'BASE TABLE';  -- Only for base tables (non-views, non-materialized views)
