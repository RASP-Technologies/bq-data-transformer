# trulens-data-transformer

# 📦 Parquet to BigQuery External Table Uploader

This Python application automates the process of:

1. Uploading **Parquet files** from a local directory to **Google Cloud Storage (GCS)**.
2. Creating **external tables** in **BigQuery** that reference the uploaded Parquet files.

All configurations (project ID, GCS bucket, dataset, service account, etc.) are maintained via an easy-to-edit `config.ini` file.

---

## 📁 Project Structure

```
parquet_uploader/
├── config/
│   └── config.ini
├── core/
│   ├── config_loader.py
│   ├── gcs.py
│   └── bigquery.py
├── utils/
│   └── file_utils.py
├── main.py
└── requirements.txt
```

---

## ⚙️ Prerequisites

- Python 3.10+
- A Google Cloud project with:
    - A BigQuery dataset
    - A GCS bucket
    - A service account with roles:
        - `BigQuery Data Editor`
        - `Storage Object Admin`
- Service account key in JSON format

---

## 🛠️ Installation

1. **Clone the repository**:

```bash
git clone https://gitlab.com/truvis-ai/trulens-data-transformer.git
cd trulens-data-transformer
```

2. **Install dependencies**:

```bash
pip install -r requirements.txt
```

3. **Set up your configuration** in `config/config.ini`:

```ini
[general]
project_id = your-gcp-project-id
dataset_id = your_bq_dataset
bucket_name = your-gcs-bucket-name
parquet_dir = ./parquet_files
gcs_prefix = parquet_data/
service_account_json = /full/path/to/your-service-account.json
```

4. **Place your `.parquet` files** in the directory defined in `parquet_dir`.

---

## 🚀 Running the Application

```bash
python main.py
```

This will:
- Upload all `.parquet` files from the local directory to the specified GCS bucket
- Create an external table in BigQuery for each file, using the filename (without extension) as the table name

---

## 📌 Notes

- External tables **do not copy data into BigQuery** — they read directly from GCS.
- Schema is **automatically inferred** from the Parquet files.
- Table names are derived from filenames (`my_file.parquet → my_file`).

---

## 📤 Example

If you have:
- A file `sales_data.parquet` in `./parquet_files/`
- Configured `dataset_id = analytics`

Running the script will:
- Upload it to `gs://your-bucket/parquet_data/sales_data.parquet`
- Create a BigQuery external table `analytics.sales_data` referencing it

---

## 📜 Minimum IAM Roles Required for GCP Service Account

To allow the service account to interact with GCS and BigQuery in a secure, least-privilege way, assign the following roles:

### 📁 1. Google Cloud Storage Access
To **read and write Parquet files** to a GCS bucket:

- **Option A (simpler):**
    - `roles/storage.objectAdmin` on the **specific bucket**

- **Option B (more restrictive):**
    - `roles/storage.objectCreator` – for writing files
    - `roles/storage.objectViewer` – for reading files

> **Note:** It is recommended to grant these roles at the **bucket level** rather than project-wide.

---

### 📊 2. BigQuery Access
To **create external tables** and **query data** in BigQuery:

- `roles/bigquery.dataEditor` – to create external tables and manage table metadata
- `roles/bigquery.user` – to run queries and interact with datasets

> If only read access is needed and no tables are being created, consider using:
> - `roles/bigquery.dataViewer`

