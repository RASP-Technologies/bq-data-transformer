from setuptools import setup, find_packages

# Read dependencies
with open("requirements.txt", encoding="utf-8") as f:
    requirements = f.read().splitlines()

setup(
    name="trulens-data-transformer",  # replace with your desired package name
    version="1.0.0",
    author="TruVis",
    packages=find_packages(),  # This will find all 5 directories if they contain __init__.py
    install_requires=requirements,
    python_requires=">=3.10",  # Adjust as needed
    include_package_data=True,
    package_data={
        "bq_scripts": ["*.sql"]
    },
    entry_points={
        "console_scripts": [
            "bq_recommendation=data_transformer.bigquery_wrapper:main",  # if you want a command-line script
        ]
    },
)
